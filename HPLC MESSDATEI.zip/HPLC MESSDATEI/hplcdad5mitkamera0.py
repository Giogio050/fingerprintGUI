#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DIY-HPLC DAD – stable10  (Mai 2025)

• CSV: sofortiges flush() nach jeder Zeile
• garantiert mind. 1 Spektrum beim Stop
• Pfad/Datei-Validierung mit Fehlermeldung
• restliche Features aus stable9 unverändert
Acceptance:
    Nach Wizard liegt calibration.autotuned.json vor, UI-Werte sind gesetzt
    (wenn „aktiv“ gewählt). Logdatei vorhanden. Dark/Baseline werden geführt
    erfasst; Exposure bleibt danach fix; SNR steigt gegenüber Startwert messbar.
"""
from __future__ import annotations

import sys
import time
import csv
import json
import pathlib
try:
    import numpy as np
except Exception:  # pragma: no cover - optional dependencies
    np = None
import threading
import queue
try:
    import cv2
    from PyQt6 import QtCore, QtWidgets, QtGui
    import pyqtgraph as pg
except Exception:  # pragma: no cover - optional dependencies
    cv2 = None
    QtCore = QtWidgets = QtGui = pg = None

# ───────── Design-Parameter ─────────────────────
# Theme colors for the GUI elements. Adjust these
# to change the overall look without touching the
# underlying measurement logic.
if pg:
    pg.setConfigOption("background", "#222")
    pg.setConfigOption("foreground", "#DDD")

# ───────── Konstanten ──────────────────────────
CAL_DEG = 2
ROI_HALF = 12
ROI_HALF_DEF = 2
CLIP_LOW, CLIP_HIGH = 1, 250
BASE_N_DEF, DARK_N_DEF = 20, 20
TICK_MS = 30
EPS = 1e-6                                    # Log-Guard
ORDER2_START_DEF = 800
LOG_INTERVAL = 5                               # Min seconds between identical logs

# Qt-Kompat (Qt5/Qt6)
if QtWidgets:
    try:
        BTN_OK, BTN_CANCEL = (QtWidgets.QDialogButtonBox.StandardButton.Ok,
                              QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        DIA_ACCEPT = QtWidgets.QDialog.DialogCode.Accepted
    except AttributeError:
        BTN_OK, BTN_CANCEL = QtWidgets.QDialogButtonBox.Ok, QtWidgets.QDialogButtonBox.Cancel
        DIA_ACCEPT = QtWidgets.QDialog.Accepted
else:
    BTN_OK = BTN_CANCEL = DIA_ACCEPT = None

# ───────── Hilfsfunktionen ─────────────────────
def find_roi(g,h=ROI_HALF):
    y=int(np.argmax(g.std(axis=1))); return slice(max(0,y-h),min(g.shape[0]-1,y+h))
def px2nm(px,c): return np.polyval(c,px)
def rotate180(img): return cv2.rotate(img,cv2.ROTATE_180)

def reduce_band(band, coefs, dark=None):
    lam = px2nm(np.arange(band.shape[1]), coefs)
    I_raw = np.median(band, axis=0)
    I_corr = I_raw - dark if dark is not None and dark.shape == I_raw.shape else I_raw
    return lam, I_raw, I_corr


def ensure_monotonic(lam: np.ndarray, I: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    lam, I = lam.copy(), I.copy()
    if np.all(np.diff(lam) < 0):
        lam, I = lam[::-1], I[::-1]
    else:
        d = np.diff(lam)
        if np.any(d <= 0):
            idx = np.argsort(lam)
            lam, I = lam[idx], I[idx]
    lam, idx = np.unique(lam, return_index=True)
    return lam, I[idx]


def hampel_filter(x: np.ndarray, k: int = 5, t0: float = 3.0) -> np.ndarray:
    n = x.size
    y = x.copy()
    k2 = k // 2
    for i in range(k2, n - k2):
        window = x[i - k2:i + k2 + 1]
        med = np.median(window)
        mad = np.median(np.abs(window - med))
        if mad > 0 and abs(x[i] - med) > t0 * 1.4826 * mad:
            y[i] = med
    return y


def mov_avg(x: np.ndarray, n: int) -> np.ndarray:
    if n <= 1:
        return x
    k = np.ones(n) / n
    return np.convolve(x, k, mode='same')


def open_default_camera():
    """Open camera index 0 if available, otherwise fallback to 0.

    Returns
    -------
    cv2.VideoCapture | None
        The opened camera object or ``None`` when no camera is available.
    """
    if cv2 is None:
        return None
    for idx in (0, 1):
        cam = cv2.VideoCapture(idx, cv2.CAP_DSHOW)
        if cam.isOpened():
            cam.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0)
            cam.set(cv2.CAP_PROP_AUTO_WB, 0)
            return cam
    return None

# Pfad zur gespeicherten Kalibrierung
CAL_FILE = pathlib.Path(__file__).with_name("calibration.json")
AUTOTUNE_FILE = pathlib.Path(__file__).with_name("calibration.autotuned.json")


def save_calibration(coefs: np.ndarray, roi: slice) -> None:
    """Persistiere Polynomialkoeffizienten und ROI."""
    data = {"coefs": [float(c) for c in coefs], "roi": [roi.start, roi.stop]}
    CAL_FILE.write_text(json.dumps(data))


def load_calibration() -> tuple[np.ndarray, slice]:
    """Lade Kalibrierung aus ``CAL_FILE``.

    Der aktuelle Standard speichert die Polynomialkoeffizienten und den ROI als
    ``{"coefs": [...], "roi": [start, stop]}``. \n
    Einige frühere Versionen (z. B. das refactored Package) legten jedoch eine
    Liste von Kalibrierpunkten ab. Diese älteren Dateien werden hier erkannt und
    in eine Polynomkalibrierung überführt, sodass die Messsoftware weiterhin
    starten kann.
    """

    data = json.loads(CAL_FILE.read_text())

    # Neuere Struktur
    if isinstance(data, dict) and "coefs" in data:
        coefs = np.array(data["coefs"], dtype=float)
        roi = slice(*data.get("roi", [None, None]))
        return coefs, roi

    # Alte Struktur: Liste von Punkten
    if isinstance(data, list) and data:
        pix = []
        wls = []
        for entry in data:
            if isinstance(entry, dict):
                pix.append(float(entry.get("pixel", 0)))
                wls.append(float(entry.get("wavelength_nm", 0)))
            elif isinstance(entry, (list, tuple)) and len(entry) >= 2:
                pix.append(float(entry[0]))
                wls.append(float(entry[1]))
        if len(pix) >= 2:
            coefs = np.polyfit(pix, wls, CAL_DEG)
            return coefs, slice(None)

    raise RuntimeError("Ungültiges Format der calibration.json")


def load_autotune() -> dict | None:
    """Load tuning parameters from ``calibration.autotuned.json`` if present."""
    if AUTOTUNE_FILE.exists():
        try:
            data = json.loads(AUTOTUNE_FILE.read_text())
            if isinstance(data, dict):
                return data.get("tuning", data)
        except Exception:
            pass
    return None
if np is not None and cv2 is not None and QtCore is not None and QtWidgets is not None and pg is not None:
    
    
    # ───────── Kamera-Thread ───────────────────────
    class CamWorker(QtCore.QThread):
        frame_ready = QtCore.pyqtSignal(np.ndarray)
    
        def __init__(self, cam, roi, roi_half):
            super().__init__()
            self.cam, self.roi, self.running = cam, roi, True
            self.auto_roi = True
            self.roi_half = roi_half
            self.autoexp = False
            self._yc = None
            self.roi_alpha = 0.3
            self.roi_hyst = 1
    
        def run(self):
            while self.running:
                ok, f = self.cam.read()
                if ok:
                    g = cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY)
                    if self.auto_roi:
                        y_raw = int(np.argmax(g.std(axis=1)))
                        if self._yc is None:
                            self._yc = y_raw
                        else:
                            self._yc += self.roi_alpha * (y_raw - self._yc)
                        c_new = round(self._yc)
                        if self.roi.start is None or self.roi.stop is None:
                            c_curr = c_new
                        else:
                            c_curr = (self.roi.start + self.roi.stop) // 2
                        if (self.roi.start is None or self.roi.stop is None) or abs(c_new - c_curr) >= self.roi_hyst:
                            h = self.roi_half
                            self.roi = slice(max(0, c_new - h), min(g.shape[0] - 1, c_new + h))
                    if self.roi.start is None or self.roi.stop is None:
                        c = g.shape[0] // 2
                        h = self.roi_half
                        self.roi = slice(max(0, c - h), min(g.shape[0] - 1, c + h))
                    g = g[self.roi, :]
                    self.frame_ready.emit(cv2.medianBlur(g.astype(np.uint8), 3).astype(float))
                self.msleep(TICK_MS)
    
        def stop(self):
            self.running = False
            self.wait()
    
    # ───────── Kalibrier-Dialog ────────────────────
    class Calib(QtWidgets.QMainWindow):
        done = QtCore.pyqtSignal(object)          # (cam, coefs, roi)
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Kalibrierung"); self.resize(1050,520)
    
            # Layout
            splitter=QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
            self.raw_img=pg.ImageView(); splitter.addWidget(self.raw_img)
            self.roi_img=pg.ImageView(); splitter.addWidget(self.roi_img)
            self.raw_plot=pg.PlotWidget(title="Rohspektrum (Pixel)")
            self.raw_plot.setLabel('bottom','Pixel')
            self.raw_plot.showGrid(x=True, y=True, alpha=0.3)
            splitter.addWidget(self.raw_plot)
            self.setCentralWidget(splitter)
    
            # Toolbar
            tb=QtWidgets.QToolBar(); self.addToolBar(tb)
            self.chk_auto=QtWidgets.QCheckBox("Auto-ROI"); self.chk_auto.setChecked(True); tb.addWidget(self.chk_auto)
            self.btn_next=QtWidgets.QPushButton("Weiter →"); self.btn_next.setEnabled(False); tb.addWidget(self.btn_next)
            self.lbl_r2=QtWidgets.QLabel(); tb.addWidget(self.lbl_r2)
    
            # Kamera automatisch öffnen (Index 1 bevorzugt)
            self.cam = open_default_camera()
            if not self.cam or not self.cam.isOpened():
                QtWidgets.QMessageBox.critical(self, "Fehler", "Kamera nicht verfügbar")
                sys.exit()
    
            self.points=[]; self.roi=slice(None)
            self.roi_img.scene.sigMouseClicked.connect(self._click_roi)
            self.raw_plot.scene().sigMouseClicked.connect(self._click_plot)
            self.btn_next.clicked.connect(self._finish)
    
            self.tmr=QtCore.QTimer(self); self.tmr.timeout.connect(self._loop); self.tmr.start(TICK_MS)
    
        # Live-Loop
        def _loop(self):
            ok,f=self.cam.read()
            if not ok:return
            g=cv2.cvtColor(rotate180(f),cv2.COLOR_BGR2GRAY)
            if self.chk_auto.isChecked(): self.roi=find_roi(g)
            self.raw_img.setImage(g.T,autoLevels=False,levels=(0,255))
            self.roi_img.setImage(g[self.roi,:].T,autoLevels=False,levels=(0,255))
            self.raw_plot.plot(g[self.roi,:].mean(0),clear=True)
    
        # Klick in ROI-Bild
        def _click_roi(self,ev):
            if ev.button()!=QtCore.Qt.MouseButton.LeftButton:return
            x=self.roi_img.getImageItem().mapFromScene(ev.scenePos()).x()
            self._add_point(x)
    
        # Klick in Roh-Plot
        def _click_plot(self,ev):
            if ev.button()!=QtCore.Qt.MouseButton.LeftButton:return
            vb=self.raw_plot.getViewBox()
            x=vb.mapSceneToView(ev.scenePos()).x()
            self._add_point(x)
    
        # Punkt aufnehmen
        def _add_point(self,x):
            lam,ok=QtWidgets.QInputDialog.getDouble(self,"λ","nm",254,190,2000,5)
            if not ok:return
            self.points.append((x,lam))
            self.roi_img.addItem(pg.ScatterPlotItem([x],[0],size=8,brush='m'))
            if len(self.points)>=CAL_DEG+1:
                xs,ls=zip(*self.points)
                self.coefs=np.polyfit(xs,ls,CAL_DEG)
                fit=np.polyval(self.coefs,xs)
                r2=1-np.sum((np.array(ls)-fit)**2+1e-12)/np.sum((np.array(ls)-np.mean(ls))**2+1e-12)
                self.lbl_r2.setText(f"R² = {r2:.4f}"); self.btn_next.setEnabled(True)
    
        def _finish(self):
            if hasattr(self,'coefs'):
                save_calibration(self.coefs, self.roi)
                self.done.emit((self.cam,self.coefs,self.roi))
                self.tmr.stop(); self.hide()
    
    # ───────── Autotune Wizard ──────────────────────
    class AutotuneWizard(QtWidgets.QDialog):
        def __init__(self, parent, cam, coefs, roi):
            super().__init__(parent)
            self.setWindowTitle("Calibration-Autotuned")
            self.cam = cam
            self.coefs = coefs
            self.roi = roi
            self.log = QtWidgets.QPlainTextEdit(readOnly=True)
            self.btn_back = QtWidgets.QPushButton("Zurück")
            self.btn_next = QtWidgets.QPushButton("Weiter")
            self.btn_start = QtWidgets.QPushButton("Start")
            self.btn_cancel = QtWidgets.QPushButton("Abbrechen")
            btn_box = QtWidgets.QHBoxLayout()
            for b in (self.btn_back, self.btn_next, self.btn_start, self.btn_cancel):
                btn_box.addWidget(b)
            lay = QtWidgets.QVBoxLayout(self)
            lay.addWidget(self.log)
            lay.addLayout(btn_box)
            self.btn_back.clicked.connect(self._back)
            self.btn_next.clicked.connect(self._next)
            self.btn_start.clicked.connect(self._start)
            self.btn_cancel.clicked.connect(self.reject)
            self.steps = [
                self._prep,
                self._darkframes,
                self._baseline,
                self._autoexposure,
                self._flicker,
                self._snr,
                self._roi_opt,
                self._smooth_opt,
                self._finish,
            ]
            self.idx = 0
            self.data = {"name": "Calibration-Autotuned", "tuning": {}}
            self.log.appendPlainText("Wizard bereit. Klicken Sie Start.")
    
        # ----- Wizard control -----
        def _start(self):
            self.btn_start.setEnabled(False)
            self.idx = 0
            self._run_step()
    
        def _next(self):
            self.idx += 1
            if self.idx < len(self.steps):
                self._run_step()
            else:
                self.accept()
    
        def _back(self):
            if self.idx > 0:
                self.idx -= 1
                self._run_step()
    
        def _run_step(self):
            self.log.appendPlainText(f"Schritt {self.idx+1}/{len(self.steps)} …")
            self.steps[self.idx]()
    
        # ----- Schritte (vereinfacht) -----
        def _prep(self):
            path = CAL_FILE
            if path.exists():
                base = json.loads(path.read_text())
            else:
                base = {"coefs": [float(c) for c in self.coefs], "roi": [self.roi.start, self.roi.stop]}
            base["name"] = "Calibration-Autotuned"
            base["tuning"] = {}
            self.data.update(base)
            self.data["tuning"]["flicker_thresh"] = float(self.parent().spin_flicker.value())
            out = path.with_name("calibration.autotuned.json")
            out.write_text(json.dumps(self.data, indent=2))
            self.log.appendPlainText("calibration.autotuned.json erzeugt.")
    
        def _darkframes(self):
            self.log.appendPlainText("Darkframes aufnehmen …")
            frames = []
            for _ in range(50):
                ok, f = self.cam.read()
                if ok:
                    frames.append(cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY))
                    QtCore.QThread.msleep(5)
            if frames:
                stack = np.median(frames, axis=0)
                self.log.appendPlainText(f"Darkframe: min {stack.min():.1f} max {stack.max():.1f} std {stack.std():.1f}")
            else:
                self.log.appendPlainText("Keine Frames erhalten.")
    
        def _baseline(self):
            self.log.appendPlainText("Baseline aufnehmen …")
            frames = []
            for _ in range(50):
                ok, f = self.cam.read()
                if ok:
                    frames.append(cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY))
                    QtCore.QThread.msleep(5)
            if frames:
                stack = np.median(frames, axis=0)
                self.log.appendPlainText(f"Baseline: min {stack.min():.1f} max {stack.max():.1f} std {stack.std():.1f}")
    
        def _autoexposure(self):
            self.log.appendPlainText("Auto-Exposure …")
            for i in range(10):
                ok, f = self.cam.read()
                if not ok:
                    continue
                g = cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY)
                p99 = np.percentile(g, 99)
                target = 0.7 * 255
                if abs(p99 - target) <= 0.1 * 255:
                    break
                exp = self.cam.get(cv2.CAP_PROP_EXPOSURE)
                exp *= target / max(p99, 1)
                self.cam.set(cv2.CAP_PROP_EXPOSURE, exp)
                QtCore.QThread.msleep(50)
            self.data["tuning"]["exposure_fixed"] = float(self.cam.get(cv2.CAP_PROP_EXPOSURE))
            self.log.appendPlainText(f"Exposure fixiert: {self.data['tuning']['exposure_fixed']}")
    
        def _flicker(self):
            self.log.appendPlainText("Flicker-Analyse …")
            dur = 0.3
            frames = []
            t0 = time.time()
            while time.time() - t0 < dur:
                ok, f = self.cam.read()
                if ok:
                    g = cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY)
                    frames.append(g.mean())
            if len(frames) > 1:
                fft = np.abs(np.fft.rfft(frames))
                freqs = np.fft.rfftfreq(len(frames), d=dur/len(frames))
                peak = freqs[np.argmax(fft[1:])+1]
                if abs(peak-100) < 5:
                    self.data["tuning"]["mains_freq"] = 50
                elif abs(peak-120) < 5:
                    self.data["tuning"]["mains_freq"] = 60
                else:
                    self.data["tuning"]["mains_freq"] = "auto"
            else:
                self.data["tuning"]["mains_freq"] = "auto"
            self.data["tuning"]["mains_averaging"] = True
            self.log.appendPlainText(f"mains_freq={self.data['tuning']['mains_freq']}")
    
        def _snr(self):
            self.log.appendPlainText("SNR bestimmen …")
            ok, f = self.cam.read()
            if ok:
                g = cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY)[self.roi,:]
                lam = px2nm(np.arange(g.shape[1]), self.coefs)
                mask = (lam >= 650) & (lam <= 700)
                if np.any(mask):
                    s = g[:,mask].mean()
                    n = g[:,mask].std()
                    snr0 = s/max(n,EPS)
                else:
                    snr0 = 1.0
            else:
                snr0 = 1.0
            target, ok = QtWidgets.QInputDialog.getDouble(self, "SNR-Ziel", "SNR", 20, 1, 100, 1)
            if not ok:
                target = 20
            t0 = 0.2
            t_needed = t0 * (target/max(snr0,1e-3))**2
            t_needed = max(0.2, min(10.0, t_needed))
            self.data["tuning"]["snr_target"] = float(target)
            self.data["tuning"]["snr_measured"] = float(snr0)
            self.data["tuning"]["min_stack_ms"] = int(t_needed*1000)
            self.log.appendPlainText(f"SNR0={snr0:.2f}, Ziel={target:.1f}, t={t_needed:.2f}s")
    
        def _roi_opt(self):
            self.log.appendPlainText("ROI-Höhe optimieren …")
            best = (self.roi.stop - self.roi.start)//2
            best_snr = 0
            for h in [1,2,3,4]:
                ok, f = self.cam.read()
                if not ok:
                    continue
                g = cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY)
                c = (self.roi.start + self.roi.stop)//2
                sl = slice(max(0,c-h), min(g.shape[0]-1,c+h))
                band = g[sl,:]
                lam = px2nm(np.arange(band.shape[1]), self.coefs)
                mask = (lam>=650)&(lam<=700)
                snr = band[:,mask].mean()/max(band[:,mask].std(),EPS)
                if snr > best_snr:
                    best_snr = snr; best = h
            self.data["tuning"]["roi_half"] = int(best)
            self.data["tuning"]["roi_lock_on_start"] = True
            self.log.appendPlainText(f"ROI_HALF={best}")
    
        def _smooth_opt(self):
            self.log.appendPlainText("Glättung optimieren …")
            best = 3; best_cost = -1e9
            for g in [3,5,7,9,11]:
                ok, f = self.cam.read()
                if not ok:
                    continue
                band = cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY)[self.roi,:]
                lam = px2nm(np.arange(band.shape[1]), self.coefs)
                mask = (lam>=650)&(lam<=700)
                sig = mov_avg(band.mean(0), g)
                snr = sig[mask].mean()/max(sig[mask].std(),EPS)
                cost = snr - 0.02*(g-3)
                if cost>best_cost:
                    best_cost=cost; best=g
            self.data["tuning"]["smooth_px"] = int(best)
            self.log.appendPlainText(f"smooth_px={best}")
    
        def _finish(self):
            out = CAL_FILE.with_name("calibration.autotuned.json")
            out.write_text(json.dumps(self.data, indent=2))
            self.log.appendPlainText("Daten gespeichert.")
            fn = time.strftime("autotune_%Y%m%d_%H%M%S.txt")
            out_log = out.with_name(fn)
            out_log.write_text(self.log.toPlainText())
            self.log.appendPlainText(f"Log gespeichert: {fn}")
            ret = QtWidgets.QMessageBox.question(self, "Aktiv setzen?", "Als aktiv übernehmen?")
            if ret == QtWidgets.QMessageBox.StandardButton.Yes:
                self.parent().apply_autotune(self.data["tuning"])
            self.accept()
    
    # ───────── Haupt-GUI ───────────────────────────
    class GUI(QtWidgets.QMainWindow):
        def __init__(self,p):
            super().__init__()
            self.cam,self.coefs,self.roi=p
            self.setWindowTitle("DIY-HPLC DAD – stable10"); self.resize(1250,760)
    
            # State
            self.I0=None; self.dark=None; self.dark_n=None
            self.base_n=BASE_N_DEF; self.wls=[]; self.trace={}; self.prevA={}
            self.tfactor=1; self.smooth_alpha=0.3; self.run=False
            self.lam_axis=None; self.last_band=None; self.saved_spec=False
            self.roi_half=ROI_HALF_DEF
            self.order2_start=ORDER2_START_DEF
            self._stack=[]; self._stack_t=[]; self._stack_means=[]
            self.last_stack_ms=0; self.last_stack_n=1
            self.last_snr=0; self.last_flicker=False
            self.exposure=self.cam.get(cv2.CAP_PROP_EXPOSURE)
            self.gain=self.cam.get(cv2.CAP_PROP_GAIN)
    
            # Write queue
            self.write_queue: queue.Queue = queue.Queue()
            self.write_thread = threading.Thread(target=self._write_worker, daemon=True)
            self.write_thread.start()
    
            # Layout
            cen=QtWidgets.QWidget(); grid=QtWidgets.QGridLayout(cen); self.setCentralWidget(cen)
            self.ch=pg.PlotWidget(title="Chromatogramm"); self.ch.setLabel('left','mAU')
            self.sp=pg.PlotWidget(title="Spektrum"); self.sp.setLabel('bottom','λ',units='nm'); self.sp.setLabel('left','mAU')
            self.spec=self.sp.plot(pen=pg.mkPen('c', width=2), connect='finite')
            self.ch.showGrid(x=True, y=True, alpha=0.3)
            self.sp.showGrid(x=True, y=True, alpha=0.3)
            self.val=QtWidgets.QTextEdit(readOnly=True); self.val.setFixedHeight(120)
    
            side=QtWidgets.QVBoxLayout()
            self.cmb=QtWidgets.QComboBox(); self.cmb.addItems(['s','min']); side.addWidget(self.cmb)
            self.chk_auto=QtWidgets.QCheckBox("Auto-ROI"); self.chk_auto.setChecked(True); side.addWidget(self.chk_auto)
            self.chk_autoexp=QtWidgets.QCheckBox("Auto-Exposure"); side.addWidget(self.chk_autoexp)
            self.chk_stack=QtWidgets.QCheckBox("Mains-Averaging"); side.addWidget(self.chk_stack)
            self.chk_verbose=QtWidgets.QCheckBox("Verbose Log"); self.chk_verbose.setChecked(True); side.addWidget(self.chk_verbose)
            self.cmb_freq=QtWidgets.QComboBox(); self.cmb_freq.addItems(["Auto","50","60"]); side.addWidget(self.cmb_freq)
            side.addWidget(QtWidgets.QLabel("Min-Stack-Zeit [ms]"))
            self.spin_stack=QtWidgets.QSpinBox(); self.spin_stack.setRange(0,1000); self.spin_stack.setValue(40); side.addWidget(self.spin_stack)
            side.addWidget(QtWidgets.QLabel("Glättung [Pixel]"))
            self.spin_px=QtWidgets.QSpinBox(); self.spin_px.setRange(1,99); self.spin_px.setValue(5); side.addWidget(self.spin_px)
            side.addWidget(QtWidgets.QLabel("Flicker-Schwelle"))
            self.spin_flicker=QtWidgets.QDoubleSpinBox(); self.spin_flicker.setRange(0,1); self.spin_flicker.setDecimals(4); self.spin_flicker.setSingleStep(0.0001); self.spin_flicker.setValue(0.0001); side.addWidget(self.spin_flicker)
            self.lbl_sat=QtWidgets.QLabel(); side.addWidget(self.lbl_sat)
            self.lbl_snr=QtWidgets.QLabel("SNR 0"); side.addWidget(self.lbl_snr)
            self.lbl_flicker=QtWidgets.QLabel("Flicker ?"); side.addWidget(self.lbl_flicker)
            self.lbl_exp=QtWidgets.QLabel("Exposure fix"); side.addWidget(self.lbl_exp)
            (self.btn_start,
             self.btn_stop,
             self.btn_base,
             self.btn_dark,
             self.btn_snap,
             self.btn_scan,
             self.btn_load_autotune) = [
                QtWidgets.QPushButton(t) for t in (
                    "Messung starten",
                    "Stopp",
                    "Baseline",
                    "Darkframe",
                    "Screenshot",
                    "ROI-Scan",
                    "Autotune laden…",
                )
            ]
            for b in (
                self.btn_start,
                self.btn_stop,
                self.btn_base,
                self.btn_dark,
                self.btn_snap,
                self.btn_scan,
                self.btn_load_autotune,
            ):
                side.addWidget(b)
            side.addStretch()
    
            grid.addWidget(self.ch,0,0); grid.addWidget(self.sp,0,1)
            grid.addWidget(self.val,1,0); grid.addLayout(side,1,1)
            self.lbl_status = QtWidgets.QLabel("Stack: 0/0ms | Flicker: ? | Exposure: fix | SNR 0.0 | Peak 0.0")
            grid.addWidget(self.lbl_status,2,0,1,2)
            self.lbl_snr.hide(); self.lbl_flicker.hide(); self.lbl_exp.hide()
    
            # Callbacks
            self.cmb.currentTextChanged.connect(
                lambda t:(self.ch.getAxis('bottom').setLabel(f"Zeit ({t})"),
                          setattr(self,'tfactor',1 if t=='s' else 1/60)))
            self.btn_start.clicked.connect(self._dialog)
            self.btn_stop .clicked.connect(self._stop)
            self.btn_base.clicked.connect(lambda: self._baseline())
            self.btn_dark.clicked.connect(self._darkframe)
            self.btn_snap.clicked.connect(self._snapshot)
            self.btn_scan.clicked.connect(self._roiscan)
            self.btn_load_autotune.clicked.connect(self._load_autotune)
            self.chk_auto.toggled.connect(self._set_auto_roi)
            self.chk_autoexp.toggled.connect(lambda s: setattr(self.worker,"autoexp",s))
    
            # Worker
            self.worker=CamWorker(self.cam,self.roi,self.roi_half)
            self.worker.auto_roi=self.chk_auto.isChecked()
            self.worker.frame_ready.connect(
                self._on_frame, type=QtCore.Qt.ConnectionType.QueuedConnection
            )
            self.worker.start()
            # frame queue and timer to process only latest frame
            self._latest_band=None
            self._processing_band=False
            self._frame_timer=QtCore.QTimer(self)
            self._frame_timer.timeout.connect(self._process_latest)
            self._frame_timer.start(TICK_MS)
            tuning = load_autotune()
            if tuning:
                self.apply_autotune(tuning)
    
        # ----------- Helper -------------
        def _toggle(self,state):
            for b in (self.btn_base,self.btn_dark,self.btn_start,self.btn_stop):
                b.setEnabled(state if (b is not self.btn_stop or self.run) else False)
    
        def _set_auto_roi(self, state):
            self.worker.auto_roi = state
            if not state:
                self.roi = self.worker.roi
    
        def _enqueue_write(self, func, *args, **kwargs) -> None:
            """Push a write task onto the internal queue."""
            self.write_queue.put((func, args, kwargs))
    
        def _write_worker(self) -> None:
            """Process queued file write tasks sequentially."""
            while True:
                task = self.write_queue.get()
                if task is None:
                    break
                func, args, kwargs = task
                try:
                    func(*args, **kwargs)
                finally:
                    self.write_queue.task_done()
    
        def _write_csv_row(self, row):
            """Write a CSV row and flush the file."""
            self.wr.writerow(row)
            self.fd.flush()
    
        def _write_json_init(self, meta: dict) -> None:
            """Create the JSON sidecar with initial metadata."""
            (self.csv.with_suffix('.json')).write_text(json.dumps(meta, indent=2))
    
        def _write_json(self, kw: dict) -> None:
            """Update the JSON sidecar with additional fields."""
            mp = self.csv.with_suffix('.json')
            meta = json.loads(mp.read_text())
            meta.update(kw)
            mp.write_text(json.dumps(meta, indent=2))
    
        def _write_spec_file(self, fn, lam_cut, int_cut, abs_cut,
                             exposure, gain, stack_ms, stack_n, snr, flicker):
            """Persist spectral data to an NPZ file."""
            np.savez_compressed(
                fn,
                wavelength=lam_cut.astype(np.float32),
                intensity=int_cut.astype(np.float32),
                absorbance_mau=abs_cut.astype(np.float32),
                exposure=np.float32(exposure),
                gain=np.float32(gain),
                stack_ms=np.float32(stack_ms),
                stack_n=np.int32(stack_n),
                snr=np.float32(snr),
                flicker=np.int8(1 if flicker else 0),
            )
    
        def _write_roiscan(self, fn, lam, lines, rows):
            """Write ROI scan data to an NPZ file."""
            np.savez(
                fn,
                wavelength=lam.astype(np.float32),
                intensity=np.array(lines, dtype=np.float32),
                row_index=np.array(list(rows)),
            )
    
        def _calibrate_exposure(self, target_frac=0.7, max_iter=10):
            target = target_frac * 255
            for _ in range(max_iter):
                vals = []
                for _ in range(3):
                    ok, f = self.cam.read()
                    if ok:
                        g = cv2.cvtColor(rotate180(f), cv2.COLOR_BGR2GRAY)
                        roi = self.worker.roi
                        g = g[roi, :]
                        vals.append(np.quantile(g, 0.99))
                        QtWidgets.QApplication.processEvents(); time.sleep(0.01)
                if not vals:
                    break
                m = float(np.mean(vals))
                if target * 0.9 <= m <= target * 1.1:
                    break
                exp = self.cam.get(cv2.CAP_PROP_EXPOSURE)
                if m > 0:
                    self.cam.set(cv2.CAP_PROP_EXPOSURE, exp * target / m)
            self.cam.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0)
            self.cam.set(cv2.CAP_PROP_GAIN, self.cam.get(cv2.CAP_PROP_GAIN))
            self.exposure = self.cam.get(cv2.CAP_PROP_EXPOSURE)
            self.gain = self.cam.get(cv2.CAP_PROP_GAIN)
            self.lbl_exp.setText("Exposure fix")
    
        def _update_json(self, **kw):
            if hasattr(self, 'csv'):
                self._enqueue_write(self._write_json, kw)
    
        def _log(self, msg: str, interval: float = LOG_INTERVAL, important: bool = False) -> None:
            """Append a message to the log respecting verbosity and interval.
    
            Parameters
            ----------
            msg: str
                Text to append.
            interval: float, optional
                Minimum seconds since identical message before logging again.
            important: bool, optional
                If True, log even when verbose mode is off.
            """
            if not hasattr(self, "_last_log"):
                self._last_log = {}
            now = time.time()
            if not important and not self.chk_verbose.isChecked():
                return
            last = self._last_log.get(msg, 0)
            if now - last >= interval:
                self.val.append(msg)
                self._last_log[msg] = now
    
        # ----------- Screenshot ---------
        def _snapshot(self):
            fn, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Screenshot speichern",
                str(pathlib.Path.home() / "spectrum.png"),
                "PNG Files (*.png)")
            if not fn:
                return
            pixmap = self.grab()
            pixmap.save(fn, "PNG")
            self._log(f"Screenshot gespeichert: {pathlib.Path(fn).name}", interval=0, important=True)
    
        # ----------- Dark-Frame ---------
        def _darkframe(self):
            n,ok=QtWidgets.QInputDialog.getInt(self,"Darkframes","Anzahl Frames:",DARK_N_DEF,1,999)
            if not ok: return
            self._toggle(False); self._log(f"Darkframe ({n}) …", interval=0, important=True)
            frames=[]
            orig_auto_roi = self.worker.auto_roi
            self.worker.auto_roi = False
            for _ in range(n):
                ok,f=self.cam.read()
                if ok:
                    g=cv2.cvtColor(rotate180(f),cv2.COLOR_BGR2GRAY)
                    band = g[self.roi, :]
                    frames.append(np.median(band, axis=0))
                    QtWidgets.QApplication.processEvents(); time.sleep(0.01)
            stack=np.stack(frames,0)
            spread=np.std(stack,axis=0).mean()
            if spread>1: self._log("Warnung: Darkframe instabil", important=True)
            self.dark = np.median(stack, 0)
            self.dark_n = n
            if hasattr(self, "dir"):
                np.save(
                    self.dir / "Darkframe" / f"{self.csv.stem}_dark.npy",
                    self.dark.astype(np.float32),
                )
            self.worker.roi = self.roi
            self.worker.auto_roi = orig_auto_roi
            self._log("Darkframe gespeichert.", interval=0, important=True)
            self._toggle(True)
    
        # ----------- Baseline -----------
        def _baseline(self,n=None):
            n=n or self.base_n
            self._toggle(False); self._log(f"Baseline ({n}) …", interval=0, important=True)
            frames=[]
            for _ in range(n):
                ok,f=self.cam.read()
                if ok:
                    g=cv2.cvtColor(rotate180(f),cv2.COLOR_BGR2GRAY)
                    band = g[self.roi, :]
                    frames.append(np.median(band, axis=0))
                    QtWidgets.QApplication.processEvents(); time.sleep(0.01)
            stack=np.stack(frames,0)
            spread=np.std(stack,axis=0).mean()
            if spread>1: self._log("Warnung: Baseline instabil", important=True)
            b=np.median(stack,0)
            if self.dark is not None and self.dark.shape==b.shape:
                b=b-self.dark
            b = hampel_filter(b, 5, 3)
            b = mov_avg(b, 5)
            lam=px2nm(np.arange(b.size),self.coefs)
            lam,b=ensure_monotonic(lam,b)
            self.lam_axis=lam
            self.I0=b
            self.worker.roi=self.roi
            if hasattr(self, "dir"):
                np.save(
                    self.dir / "Baseline" / f"{self.csv.stem}_baseline_I0.npy",
                    self.I0.astype(np.float32),
                )
            if hasattr(self,'csv'):
                self._update_json(baseline_frames=n)
            self._log("Baseline gesetzt.", interval=0, important=True); self._toggle(True)
    
        # ----------- ROI-Scan -----------
        def _roiscan(self):
            ok,f=self.cam.read()
            if not ok:return
            g=cv2.cvtColor(rotate180(f),cv2.COLOR_BGR2GRAY)
            roi=self.worker.roi
            if roi.start is None or roi.stop is None:
                c=g.shape[0]//2
            else:
                c=(roi.start+roi.stop)//2
            rows=range(c-3,c+4)
            lam=px2nm(np.arange(g.shape[1]),self.coefs)
            lines=[]; curves=[]
            if hasattr(self,'scan_curves'):
                for it in self.scan_curves: self.sp.removeItem(it)
            for i,r in enumerate(rows):
                if 0<=r<g.shape[0]:
                    line=g[r,:].astype(float)
                    lines.append(line)
                    curves.append(self.sp.plot(lam,line,pen=pg.mkPen(pg.intColor(i,len(rows)))))
            self.scan_curves=curves
            fn=(self.dir if hasattr(self,'dir') else pathlib.Path.home())/f"roi_scan_{int(time.time()*1000)}.npz"
            self._enqueue_write(self._write_roiscan, fn, lam, lines, rows)
            self._log(f"ROI-Scan gespeichert: {fn.name}", interval=0, important=True)

        def _load_autotune(self):
            fn, _ = QtWidgets.QFileDialog.getOpenFileName(
                self,
                "Autotune-Datei wählen",
                str(pathlib.Path.home()),
                "JSON Files (*.json)",
            )
            if not fn:
                return
            try:
                data = json.loads(pathlib.Path(fn).read_text())
                if isinstance(data, dict):
                    tuning = data.get("tuning", data)
                    if tuning:
                        self.apply_autotune(tuning)
            except Exception as e:
                QtWidgets.QMessageBox.warning(
                    self, "Fehler", f"Autotune konnte nicht geladen werden:\n{e}"
                )

        def apply_autotune(self, tuning: dict) -> None:
            self.chk_stack.setChecked(tuning.get("mains_averaging", False))
            freq = str(tuning.get("mains_freq", "Auto")).title()
            idx = self.cmb_freq.findText(freq)
            if idx >= 0:
                self.cmb_freq.setCurrentIndex(idx)
            self.spin_stack.setValue(tuning.get("min_stack_ms", self.spin_stack.value()))
            self.worker.roi_half = tuning.get("roi_half", self.worker.roi_half)
            self.chk_auto.setChecked(tuning.get("roi_lock_on_start", True))
            self.spin_px.setValue(tuning.get("smooth_px", self.spin_px.value()))
            self.spin_flicker.setValue(tuning.get("flicker_thresh", self.spin_flicker.value()))
            if "exposure_fixed" in tuning:
                self.cam.set(cv2.CAP_PROP_EXPOSURE, tuning["exposure_fixed"])
            self.chk_autoexp.setChecked(False)
    
        # ----------- Dialog -------------
        def _dialog(self):
            if self.run:return
            dlg=QtWidgets.QDialog(self); dlg.setWindowTitle("Messung konfigurieren")
            form=QtWidgets.QFormLayout(dlg)
            dur=QtWidgets.QSpinBox(maximum=999999,value=1)
            rate=QtWidgets.QSpinBox(maximum=3600,value=1)
            spe=QtWidgets.QSpinBox(minimum=100,maximum=10000,value=500)
            base_frames=QtWidgets.QSpinBox(maximum=9999,value=self.base_n)
            smooth=QtWidgets.QDoubleSpinBox(); smooth.setRange(0,1); smooth.setSingleStep(0.05); smooth.setValue(self.smooth_alpha)
            wl_entry=QtWidgets.QLineEdit("254,280,300")
            autoexp_chk=QtWidgets.QCheckBox("Auto-Belichtung vor Start"); autoexp_chk.setChecked(True)
            lock_roi_chk=QtWidgets.QCheckBox("ROI beim Start locken")
            spin_min,spin_max=[QtWidgets.QDoubleSpinBox() for _ in range(2)]
            for sp in (spin_min,spin_max): sp.setRange(190,2000)
            spin_min.setValue(190)
            spin_max.setValue(1000)
            roi_half_spin=QtWidgets.QSpinBox(maximum=99,value=self.roi_half)
            order2=QtWidgets.QDoubleSpinBox(); order2.setRange(190,2000); order2.setValue(self.order2_start)
            fname_edit = QtWidgets.QLineEdit("messung.csv")
            fname_edit.setMinimumWidth(260)

            for lbl, w in [
                ("Dauer [min] (0=∞):", dur),
                ("CSV-Intervall [s]:", rate),
                ("Spektrum-Intervall [ms]:", spe),
                ("Baseline-Frames:", base_frames),
                ("Glättung α:", smooth),
                ("λ-min:", spin_min),
                ("λ-max:", spin_max),
                ("ROI-Halbhöhe:", roi_half_spin),
                ("2. Ordnung ab [nm]:", order2),
                ("λ überwachen:", wl_entry),
                ("Auto-Belichtung vor Start:", autoexp_chk),
                ("ROI beim Start locken:", lock_roi_chk),
                ("Dateiname:", fname_edit),
            ]:
                form.addRow(lbl, w)
            bb=QtWidgets.QDialogButtonBox(BTN_OK|BTN_CANCEL); form.addRow(bb)
            bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
            if dlg.exec()!=DIA_ACCEPT:return
    
            # Params
            self.smooth_alpha=smooth.value()
            self.wl_min,self.wl_max=sorted((spin_min.value(),spin_max.value()))
            self.duration=dur.value()*60; self.rate=rate.value(); self.sint=spe.value()/1000
            self.base_n=base_frames.value()
            self.roi_half=roi_half_spin.value(); self.worker.roi_half=self.roi_half
            self.order2_start=order2.value()
            self.wls = [float(x) for x in wl_entry.text().split(",") if x.strip()]
            fname = fname_edit.text().strip()
            if not fname:
                return
            if not pathlib.Path(fname).suffix:
                fname += ".csv"
            base = pathlib.Path.cwd() / "HPLC"
            chrom_dir = base / "Chromatogramme"
            spec_dir = base / "Spektren" / f"{time.strftime('%Y-%m-%d')}_Messung_{pathlib.Path(fname).stem}"
            (spec_dir / "Baseline").mkdir(parents=True, exist_ok=True)
            (spec_dir / "Darkframe").mkdir(parents=True, exist_ok=True)
            chrom_dir.mkdir(parents=True, exist_ok=True)
            self.csv = chrom_dir / fname
            self.dir = spec_dir
            try:
                self.fd = open(self.csv, "w", newline='')
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Fehler", f"CSV kann nicht angelegt werden:\n{e}")
                return
            self.wr = csv.writer(self.fd, delimiter=',', lineterminator='\n')
            header=["time_"+self.cmb.currentText()]+[f"{w:.0f}nm" for w in self.wls]
            self._enqueue_write(self._write_csv_row, header)
    
            if lock_roi_chk.isChecked():
                self.chk_auto.setChecked(False)
                self.chk_auto.setEnabled(False)
            else:
                self.chk_auto.setEnabled(True)
            if autoexp_chk.isChecked():
                self._calibrate_exposure()
            self.exposure=self.cam.get(cv2.CAP_PROP_EXPOSURE)
            self.gain=self.cam.get(cv2.CAP_PROP_GAIN)
    
            # JSON-Sidecar
            meta={
                "start_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
                "wl_min":self.wl_min,"wl_max":self.wl_max,"wls":self.wls,
                "rate_s":self.rate,"spec_int_s":self.sint,"baseline_frames":self.base_n,
                "dark_frames":0 if self.dark_n is None else self.dark_n,
                "smooth_alpha":self.smooth_alpha,"poly_coefs":list(self.coefs),
                "roi":[self.roi.start,self.roi.stop],
                "roi_half":self.roi_half,
                "order2_start_nm":self.order2_start,
                "exposure":self.exposure,
                "gain":self.gain,
                "stack_min_ms":self.spin_stack.value(),
                "flicker_thresh":self.spin_flicker.value()
                }
            self._enqueue_write(self._write_json_init, meta)
    
            self.trace={w:[] for w in self.wls}; self.prevA={w:None for w in self.wls}
            self.saved_spec=False
            if self.I0 is None: self._baseline(self.base_n)
            self.mask=(self.lam_axis>=self.wl_min)&(self.lam_axis<=self.wl_max)
            self.I0=self.I0[self.mask]
    
            colors=[pg.intColor(i) for i in range(len(self.wls))]
            self.ch.clear(); self.chrom_curves={wl:self.ch.plot(pen=col,name=f"{wl:.0f} nm")
                                                for wl,col in zip(self.wls,colors)}
    
            self.t0=time.time(); self.next_csv=self.t0+self.rate; self.next_spec=self.t0+self.sint
            self.run=True; self.btn_start.setEnabled(False); self._log("Messung gestartet …", interval=0, important=True)
    
        # ----------- Frame -------------
        def _on_frame(self, band):
            """Receive frames from worker thread. Only keep the latest."""
            self._latest_band = band
    
        def _process_latest(self):
            """Process the most recent frame at a controlled rate."""
            if self._processing_band or self._latest_band is None:
                return
            band = self._latest_band
            self._latest_band = None
            self._processing_band = True
            try:
                self._process_frame(band)
            finally:
                self._processing_band = False
                if self._latest_band is not None:
                    QtCore.QTimer.singleShot(0, self._process_latest)
    
        def _process_frame(self,band):
            ts=time.time()
            if self.chk_stack.isChecked():
                self._stack.append(band)
                self._stack_t.append(ts)
                self._stack_means.append(band.mean())
                elapsed=self._stack_t[-1]-self._stack_t[0]
                target=self.spin_stack.value()/1000
                fsel=self.cmb_freq.currentText()
                if fsel=="50": target=max(target,2/50)
                elif fsel=="60": target=max(target,2/60)
                else: target=max(target,2/50,2/60)
                if elapsed<target: return
                shapes={b.shape for b in self._stack}
                if len(shapes)==1:
                    stack=np.stack(self._stack,0); band=stack.mean(0)
                    means=np.array(self._stack_means); var=np.var(means); mean=means.mean()
                    rel_var=var/max(mean**2,EPS)
                    self.last_flicker=rel_var>self.spin_flicker.value()
                    self.last_stack_ms=elapsed*1000
                    self.last_stack_n=len(self._stack)
                else:
                    band=self._stack[-1]
                    self.last_flicker=False
                    self.last_stack_ms=0
                    self.last_stack_n=1
                self._stack.clear(); self._stack_t.clear(); self._stack_means.clear()
            else:
                self.last_flicker=False
                self.last_stack_ms=0
                self.last_stack_n=1
            self.last_band=band
            lam, I_raw, I_corr = reduce_band(band, self.coefs, self.dark)
            lam, I_corr = ensure_monotonic(lam, I_corr)
            I_corr = hampel_filter(I_corr, 5, 3)
            I_corr = mov_avg(I_corr, self.spin_px.value())
            if self.I0 is not None and self.I0.shape == I_corr.shape:
                disp = -1000 * np.log10(np.maximum(I_corr, EPS) / np.maximum(self.I0, EPS))
            else:
                disp = I_corr.copy()
            disp[lam>=self.order2_start] = np.nan
            self.spec.setData(lam, disp)
            sat = (band >= 255).mean()
            self.lbl_sat.setText(f"Sättigung: {sat*100:.2f}%")
            self.lbl_sat.setStyleSheet("color:#F44" if sat>0.1 else "")
            snr_mask=(lam>=650)&(lam<=700)
            if np.any(snr_mask):
                snr=np.mean(I_corr[snr_mask])/max(np.std(I_corr[snr_mask]),EPS)
            else:
                snr=0.0
            self.last_snr=snr
            status = (f"Stack: {self.last_stack_n}/{self.last_stack_ms:.0f}ms | "
                      f"Flicker: {'ja' if self.last_flicker else 'nein'} | "
                      f"Exposure: {'fix' if not self.chk_autoexp.isChecked() else 'auto'} | "
                      f"SNR {snr:.1f} | Peak {np.nanmax(I_corr):.1f}")
            self.lbl_status.setText(status)
            if snr < 5:
                color = "#F00"
            elif snr < 20:
                color = "#FF0"
            else:
                color = "#0F0"
            self.lbl_status.setStyleSheet(f"color:{color}")
            if not self.run:return
            if sat>0.1: self._log("Warnung: Sättigung", important=True)
            now=time.time(); t=(now-self.t0)*self.tfactor
            mvals=[]
            for wl in self.wls:
                i_px=np.abs(lam-wl).argmin(); i0=np.abs(self.lam_axis[self.mask]-wl).argmin()
                A_raw=-1000*np.log10(np.maximum(I_corr[i_px],EPS)/np.maximum(self.I0[i0],EPS))
                A=A_raw if self.prevA[wl] is None else self.smooth_alpha*A_raw+(1-self.smooth_alpha)*self.prevA[wl]
                self.prevA[wl]=A; mvals.append(A)
                self.trace[wl].append((t,A)); self.chrom_curves[wl].setData(*zip(*self.trace[wl]))
    
            if now>=self.next_csv:
                row=[f"{t:.3f}",*[f"{v:.3f}" for v in mvals]]
                self._enqueue_write(self._write_csv_row, row)
                self._log("CSV geschrieben …"); self.next_csv+=self.rate
    
            if now>=self.next_spec:
                self._save_spec(I_corr,lam,now); self.next_spec+=self.sint
    
            if self.duration>0 and t>=self.duration*self.tfactor: self._stop()
    
        # ----------- Speichern ----------
        def _save_spec(self,band_mean,lam,ts):
            lam_cut=lam[self.mask]
            int_cut=band_mean[self.mask]
            abs_cut=-1000*np.log10(np.maximum(int_cut,EPS)/np.maximum(self.I0,EPS))
            fn = self.dir / f"{self.csv.stem}_{int(ts*1000):013d}.npz"
            self._enqueue_write(
                self._write_spec_file,
                fn,
                lam_cut,
                int_cut,
                abs_cut,
                self.exposure,
                self.gain,
                self.last_stack_ms,
                self.last_stack_n,
                self.last_snr,
                self.last_flicker,
            )
            self._update_json(
                stack_ms=self.last_stack_ms,
                stack_n=self.last_stack_n,
                snr=self.last_snr,
                flicker=bool(self.last_flicker),
            )
            self.saved_spec=True; self._log(f"Spektrum gespeichert: {fn.name}")
    
        # ----------- Stop ---------------
        def _stop(self):
            if not self.run:return
            if not self.saved_spec and self.last_band is not None:
                lam, _, I_corr = reduce_band(self.last_band, self.coefs, self.dark)
                lam, I_corr = ensure_monotonic(lam, I_corr)
                self._save_spec(I_corr,lam,time.time())
            self.write_queue.join()
            self.fd.close(); self.run=False; self.btn_start.setEnabled(True)
            self._log("Messung beendet.", interval=0, important=True)
    
        def closeEvent(self,ev):
            self.worker.stop()
            self.write_queue.put(None)
            self.write_thread.join()
            super().closeEvent(ev)
    
    # ───────── main() ─────────────────────────────
    def main(auto_tune: bool = False):
        force = "--recalibrate" in sys.argv[1:]
        if hasattr(QtCore.Qt,"AA_EnableHighDpiScaling"):
            QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling,True)
        app=QtWidgets.QApplication([sys.argv[0]])

        def start_gui(p, tuning=None):
            gui = GUI(p)
            if tuning:
                gui.apply_autotune(tuning)
            windows.append(gui)
            gui.show()
    
        if force or not CAL_FILE.exists():
            cal = Calib()
            cal.show()
            cal.done.connect(start_gui)
        else:
            cam = open_default_camera()
            if cam is None or not cam.isOpened():
                QtWidgets.QMessageBox.critical(None, "Fehler", "Kamera nicht verfügbar")
                return
            coefs, roi = load_calibration()
            tuning = None
            if auto_tune:
                wiz = AutotuneWizard(None, cam, coefs, roi)
                if wiz.exec() == DIA_ACCEPT:
                    tuning = wiz.data.get("tuning", {})
            start_gui((cam, coefs, roi), tuning)
        sys.exit(app.exec())
    
    if __name__ == "__main__":
        windows = []
        main(auto_tune="--autotune" in sys.argv[1:])

else:
    def main(auto_tune: bool = False):
        raise RuntimeError('Required GUI dependencies are not available.')
